<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * AJAX pagination for the Product List shortcode
 */
if ( ! function_exists( 'us_ajax_product_list' ) ) {
	add_action( 'wp_ajax_nopriv_us_ajax_product_list', 'us_ajax_product_list' );
	add_action( 'wp_ajax_us_ajax_product_list', 'us_ajax_product_list' );

	function us_ajax_product_list() {
		if ( ! check_ajax_referer( 'us_product_list', '_nonce', FALSE ) ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		// Passing the next page via AJAX ...
		$template_vars = us_array_merge(
			us_shortcode_atts( us_maybe_get_post_json( 'template_vars' ), 'us_product_list' ),
			// This parameter is required by the product list template
			array( 'shortcode_base' => 'us_product_list' )
		);

		// Set the page number if available
		if ( isset( $_POST['paged'] ) ) {
			$template_vars['paged'] = (int) $_POST['paged'];
		}

		us_load_template( 'templates/elements/product_list', $template_vars );

		die;
	}
}
